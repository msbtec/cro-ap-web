<?php

return [
    'site_title' => 'CRO-AP',
];
